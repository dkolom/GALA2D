% Visualize solution interpolated on a Cartesian grid
clear all;
close all;

set(0,'DefaultaxesFontSize',9);
set(0,'DefaulttextFontsize',9);
set(0,'DefaultaxesFontName','Times');
set(0,'DefaulttextFontName','Times');

h_fig = figure(1); 
set(h_fig,'Units','centimeters','Position',[2.5 7 5.5 5.5],'PaperPositionMode','auto');  
clf;

Nx = 2048;
Ny = 2048;
Lx = 1;
Ly = 1;

dx = Lx/Nx;
dy = Ly/Ny;

x = dx * (0:Nx-1);
y = dy * (0:Ny-1);
[yy,xx] = meshgrid(y,x);

plot([-100 -100],[-100 100],'k-'); hold on;
plot([-100 -100],[-100 100],'k:');

% Numerical
phi = importdata('cartfile_t10.dat');

phic1 = exp(-10*0.1^2);
contour(xx,yy,phi.',phic1,'b'); hold on;
phic2 = exp(-10*0.15^2);
contour(xx,yy,phi.',phic2,'g');
phic3 = exp(-10*0.2^2);
contour(xx,yy,phi.',phic3,'r');

hold on;

% Exact (initial)
phi = importdata('cartfile_t0.dat');

phic1 = exp(-10*0.1^2);
contour(xx(1:32:end,1:32:end),yy(1:32:end,1:32:end),phi(1:32:end,1:32:end).',phic1,'b:');
phic2 = exp(-10*0.15^2);
contour(xx(1:32:end,1:32:end),yy(1:32:end,1:32:end),phi(1:32:end,1:32:end).',phic2,'g:')
phic3 = exp(-10*0.2^2);
contour(xx(1:32:end,1:32:end),yy(1:32:end,1:32:end),phi(1:32:end,1:32:end).',phic3,'r:')

axis([0 1 0 1]);
grid off;
set(gca,'XTick',[0 0.5 1]);
set(gca,'YTick',[0 0.5 1]);

legend('Numerical','Exact','Location','SouthWest');

title('\rm{(}\it{c}\rm{)}');

set(gca,'PlotBoxAspectRatioMode','manual');
set(gca,'PlotBoxAspectRatio',[1 1 1]);

print('-dpng','snapshot_t10.png');    
print('-depsc','snapshot_t10.eps');