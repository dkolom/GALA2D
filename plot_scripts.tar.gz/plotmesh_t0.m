% Visualize adaptive mesh in 2d
clear all;
close all;

set(0,'DefaultaxesFontSize',9);
set(0,'DefaulttextFontsize',9);
set(0,'DefaultaxesFontName','Times');
set(0,'DefaulttextFontName','Times');

h_fig = figure(1); 
set(h_fig,'Units','centimeters','Position',[2.5 7 5.5 5.5],'PaperPositionMode','auto');  
clf;

meshdata=importdata('meshfile_t0.dat');

for j=1:length(meshdata)
  x0 = meshdata(j,1);
  y0 = meshdata(j,2);
  x1 = meshdata(j,3);
  y1 = meshdata(j,4);

  plot([x0 x1 x1 x0 x0],[y0 y0 y1 y1 y0],'k-'); hold on;
end;

%xlabel('x_1');
%ylabel('x_2');

axis([0 1 0 1]);
grid off;
set(gca,'XTick',[0 0.5 1]);
set(gca,'YTick',[0 0.5 1]);

title('\rm{(}\it{a}\rm{)}');

set(gca,'PlotBoxAspectRatioMode','manual');
set(gca,'PlotBoxAspectRatio',[1 1 1]);

print('figmesh_t0.eps','-deps');
print('figmesh_t0.png','-dpng');