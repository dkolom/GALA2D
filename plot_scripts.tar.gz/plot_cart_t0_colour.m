% Visualize solution interpolated on a Cartesian grid
clear all;
close all;

set(0,'DefaultaxesFontSize',9);
set(0,'DefaulttextFontsize',9);
set(0,'DefaultaxesFontName','Times');
set(0,'DefaulttextFontName','Times');

h_fig = figure(1); 
set(h_fig,'Units','centimeters','Position',[2.5 7 5.5 5.5],'PaperPositionMode','auto');  
clf;

Nx = 2048;
Ny = 2048;
Lx = 1;
Ly = 1;

dx = Lx/Nx;
dy = Ly/Ny;

x = dx * (0:Nx-1);
y = dy * (0:Ny-1);
[yy,xx] = meshgrid(y,x);

phi = importdata('cartfile_t0.dat');

phic1 = exp(-10*0.1^2);
contour(xx,yy,phi.',phic1,'b'); hold on;
phic2 = exp(-10*0.15^2);
contour(xx,yy,phi.',phic2,'g');
phic3 = exp(-10*0.2^2);
contour(xx,yy,phi.',phic3,'r');

legend('\it{r}\rm{=0.1}','0.15','0.2','Location','SouthWest');

axis([0 1 0 1]);
grid off;
set(gca,'XTick',[0 0.5 1]);
set(gca,'YTick',[0 0.5 1]);

title('\rm{(}\it{a}\rm{)}');

set(gca,'PlotBoxAspectRatioMode','manual');
set(gca,'PlotBoxAspectRatio',[1 1 1]);

print('-dpng','snapshot_t0.png');    
print('-depsc','snapshot_t0.eps');
